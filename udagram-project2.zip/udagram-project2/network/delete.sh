aws cloudformation delete-stack \
--stack-name $1 --profile $2
